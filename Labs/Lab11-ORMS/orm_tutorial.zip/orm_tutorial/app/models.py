from app import db

# Your Customer Database code should go here
